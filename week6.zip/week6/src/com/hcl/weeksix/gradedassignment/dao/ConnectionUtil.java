package com.hcl.weeksix.gradedassignment.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionUtil {

	private static String url = "jdbc:mysql://localhost:3306/db2";
	private static String username = "root";
	private static String password = "Saikumar@0533";

	private static Connection con;

	static {

		try {
			con = DriverManager.getConnection(url, username, password);
			System.out.println(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static Connection getConnection() {
		return con;
	}
}
