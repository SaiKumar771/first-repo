package com.hcl.weeksix.gradedassignment.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

  public class MoviesDAO {

	private static Connection con = ConnectionUtil.getConnection();

	public String addMovies(int id, String title, int year, String category) {

		try {

			String sql = "insert into movies values (?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, title);
			ps.setInt(3, year);
			ps.setString(4, category);
			ps.executeUpdate();
			ps.close();

			return "Movie Added Successfully!";

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Error in Adding Movies";
		}

	}

}
