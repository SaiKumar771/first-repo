package com.hcl.weeksix.gradedassignment.service;

import com.hcl.weeksix.gradedassignment.dao.MoviesDAO;

public class Service implements IService {

	MoviesDAO dao = new MoviesDAO();

	@Override
	public String addMovies(int id, String title, int year, String category) {
		// TODO Auto-generated method stub
		return dao.addMovies(id, title, year, category);
	}

}
