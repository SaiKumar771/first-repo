package com.hcl.weeksix.gradedassignment.service;

public interface IMovies {

	public int getId();

	public void setId(int id);

	public String getTitle();

	public void setTitle(String title);

	public int getYear();

	public void setYear(int year);

	public String getCategory();

	public void setCategory(String category);

}
