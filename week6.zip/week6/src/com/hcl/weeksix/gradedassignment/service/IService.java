package com.hcl.weeksix.gradedassignment.service;

public interface IService {

	public String addMovies(int id, String title, int year, String category);

}
