package com.hcl.weeksix.gradedassignment.beans;

import com.hcl.weeksix.gradedassignment.service.IMovies;

public class MoviesFactory {

	public IMovies getShape(String movieCategory) {
		if (movieCategory == null) {
			return null;
		}
		if (movieCategory.equalsIgnoreCase("TopRatedMovies")) {
			return new TopRatedMovies();

		} else if (movieCategory.equalsIgnoreCase("TopRatedIndia")) {
			return new TopRatedIndia();

		} else if (movieCategory.equalsIgnoreCase("ComingMovies")) {
			return new ComingMovies();

		} else if (movieCategory.equalsIgnoreCase("MoviesInTheaters")) {
			return new MoviesInTheaters();

		}

		return null;
	}
}
