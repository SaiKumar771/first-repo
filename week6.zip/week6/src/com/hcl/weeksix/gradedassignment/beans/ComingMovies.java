package com.hcl.weeksix.gradedassignment.beans;

import com.hcl.weeksix.gradedassignment.service.IMovies;

public class ComingMovies implements IMovies{
	
	private int id;
	private String title;
	private int year;
	private String category = "Coming Movies";

	@Override
	public int getId() {
		// TODO Auto-generated method stub
		return this.id;
	}

	@Override
	public void setId(int id) {
		// TODO Auto-generated method stub
		this.id = id;
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return this.title;
	}

	@Override
	public void setTitle(String title) {
		// TODO Auto-generated method stub
		this.title = title;
	}

	@Override
	public int getYear() {
		// TODO Auto-generated method stub
		return this.year;
	}

	@Override
	public void setYear(int year) {
		// TODO Auto-generated method stub
		this.year = year;
	}

	@Override
	public String getCategory() {
		// TODO Auto-generated method stub
		return category;
	}

	@Override
	public void setCategory(String category) {
		// TODO Auto-generated method stub
		this.category = category;
	}

}
