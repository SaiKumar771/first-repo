package com.hcl.weeksix.gradedassignment.main;

import java.util.Scanner;

import com.hcl.weeksix.gradedassignment.beans.*;
import com.hcl.weeksix.gradedassignment.service.IMovies;
import com.hcl.weeksix.gradedassignment.service.Service;

public class Demo {

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Service service = new Service();

		Scanner s = new Scanner(System.in);
		
		
		
		while(true)
		{
		System.out.println(
				"Enter 1 for Coming Soon movies\nEnter 2 for Top Rated Movies\nEnter 3 for Top Rated India Movies\nEnter 4 Movies In Theaters \nEnter 5 to exit");
		int choice = s.nextInt();
		boolean isTrue = true;
		switch (choice) {
		
		case 1:
			while(isTrue)
			{
			System.out.println("Enter 1 to add Movies\nEnter 2 to Exit\n");
			int input1 = s.nextInt();
			switch (input1) {

			case 1:
				ComingMovies cm = new ComingMovies();
				System.out.println("Enter Movie id");
				int id = s.nextInt();
				System.out.println("Enter Movie title");
				String title = s.next();
				System.out.println("Enter Movie year");
				int year = s.nextInt();
				IMovies comingMovies = new ComingMovies();
				comingMovies.setId(id);
				comingMovies.setTitle(title);
				comingMovies.setYear(year);
				comingMovies.setCategory(cm.getCategory());
				System.out.println(service.addMovies(id, title, year, cm.getCategory()));
				break;
			case 2:
				System.exit(1);
				break;

			default:
				System.out.println("Invalid Choice");
				break;
			
			}
			break;
			}
		case 2:
			while(true)
			{
			System.out.println("Enter 1 to add Movies\nEnter 2 to Exit\n");
			int input2 = s.nextInt();
			switch (input2) {

			case 1:
				TopRatedMovies trp = new TopRatedMovies();
				System.out.println("Enter Movie id");
				int id = s.nextInt();
				System.out.println("Enter Movie title");
				String title = s.next();
				System.out.println("Enter Movie year");
				int year = s.nextInt();
				IMovies topRatedMovies = new TopRatedMovies();
				topRatedMovies.setId(id);
				topRatedMovies.setTitle(title);
				topRatedMovies.setYear(year);
				topRatedMovies.setCategory(trp.getCategory());
				System.out.println(service.addMovies(id, title, year, trp.getCategory()));
				break;
			case 2:
				System.exit(1);

			default:
				System.out.println("Invalid Choice");
				break;
			}
			break;
			}
		case 3:
			while(true)
			{
			System.out.println("Enter 1 to add Movies\nEnter 2 to Exit\n");
			int input3 = s.nextInt();
			switch (input3) {

			case 1:
				TopRatedIndia tri = new TopRatedIndia();
				System.out.println("Enter Movie id");
				int id = s.nextInt();
				System.out.println("Enter Movie title");
				String title = s.next();
				System.out.println("Enter Movie year");
				int year = s.nextInt();
				IMovies topRatedIndia = new TopRatedIndia();
				topRatedIndia.setId(id);
				topRatedIndia.setTitle(title);
				topRatedIndia.setYear(year);
				topRatedIndia.setCategory(tri.getCategory());
				System.out.println(service.addMovies(id, title, year, tri.getCategory()));
				break;
			case 2:
				System.exit(1);

			default:
				System.out.println("Invalid Choice");
				break;
			}
			break;
			}
		case 4:
			while(true)
			{
			System.out.println("Enter 1 to add Movies\nEnter 2 to Exit\n");
			int input4 = s.nextInt();
			switch (input4) {

			case 1:
				MoviesInTheaters mit = new MoviesInTheaters();
				System.out.println("Enter Movie id");
				int id = s.nextInt();
				System.out.println("Enter Movie title");
				String title = s.next();
				System.out.println("Enter Movie year");
				int year = s.nextInt();
				IMovies moviesInTheaters = new MoviesInTheaters();
				moviesInTheaters.setId(id);
				moviesInTheaters.setTitle(title);
				moviesInTheaters.setYear(year);
				moviesInTheaters.setCategory(mit.getCategory());
				System.out.println(service.addMovies(id, title, year, mit.getCategory()));
				break;
			case 2:
				System.exit(1);
				break;

			default:
				System.out.println("Invalid Choice");
				break;
			}
			break;
			}
		case 5: System.exit(1);
		break;
		default:
			System.out.println("Invalid Choice");
			break;
		}

	}
	}
}
